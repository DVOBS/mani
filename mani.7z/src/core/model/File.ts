import { JsonObject, JsonProperty } from '@/core/json2typescript'

@JsonObject('Directory')
export default class Directory {
  /** 应用名称 */
  @JsonProperty('name', String, true)
  public name = 'ComponentName.Vue';

  public content = ''
}
