/**
 * Virtual any type for the property decorator.
 */
export class Any {}
