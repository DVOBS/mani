module.exports = {
  pages: {
    index: 'tests/dev/main.ts',
    layout: 'tests/layout-dev/main.ts'
  }
}
